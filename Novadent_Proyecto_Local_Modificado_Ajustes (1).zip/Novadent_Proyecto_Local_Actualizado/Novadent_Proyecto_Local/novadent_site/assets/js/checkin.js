document.addEventListener('DOMContentLoaded',()=>{
  const params=new URLSearchParams(location.search),code=params.get('ref');
  const details=document.getElementById('checkinDetails'),status=document.getElementById('checkinStatus'),button=document.getElementById('confirmArrival');
  let item=Novadent.getAppointments().find(a=>a.code===code);
  if(!item){details.textContent='No encontramos una reserva con ese localizador en este navegador.';button.disabled=true;status.textContent='Comprueba que el QR pertenece a esta demostración local.';return;}
  details.textContent=`Reserva ${item.code} · ${item.service} · ${Novadent.formatDate(item.date)} a las ${item.time}.`;
  if(item.checkedIn){status.textContent='La llegada ya aparece confirmada en esta demostración.';button.textContent='Llegada confirmada';button.disabled=true;}
  button.addEventListener('click',()=>{const list=Novadent.getAppointments();const current=list.find(a=>a.code===code);if(!current)return;current.checkedIn=true;current.status='Llegada confirmada · demostración';Novadent.saveAppointments(list);status.textContent='✓ Llegada registrada en este navegador. Puedes dirigirte a recepción.';button.textContent='Llegada confirmada';button.disabled=true;});
});
