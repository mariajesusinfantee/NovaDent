document.addEventListener('DOMContentLoaded',()=>{
  const form=document.getElementById('contactForm');if(!form)return;
  form.addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('contactName').value.trim(),email=document.getElementById('contactEmail').value.trim(),subject=document.getElementById('contactSubject').value,message=document.getElementById('contactMessage').value.trim();const body=`Nombre: ${name}\nCorreo: ${email}\n\nMensaje:\n${message}`;const mailto=`mailto:citas@clinicanovadent.es?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;document.getElementById('contactMessageStatus').textContent='Se va a abrir tu aplicación de correo para completar el envío.';location.href=mailto;});
});
