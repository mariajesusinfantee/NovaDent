document.addEventListener('DOMContentLoaded', () => {
  const $ = id => document.getElementById(id);
  const login = $('patientLogin');
  const dashboard = $('patientDashboard');
  const loginForm = $('patientLoginForm');
  if (!loginForm) return;
  let activeEmail = '';

  function setMessage(text, error = false) {
    $('loginMessage').textContent = text;
    $('loginMessage').style.color = error ? '#b46d79' : '#668d79';
  }

  loginForm.addEventListener('submit', event => {
    event.preventDefault();
    const email = $('loginEmail').value.trim().toLowerCase();
    const code = $('loginCode').value.trim().toUpperCase();
    const found = Novadent.getAppointments().find(a => a.email.toLowerCase() === email && a.code.toUpperCase() === code);
    if (!found) {
      setMessage('No encontramos esa combinación. Comprueba el correo y el localizador.', true);
      return;
    }
    activeEmail = email;
    showDashboard();
  });

  function showDashboard() {
    login.hidden = true;
    dashboard.hidden = false;
    const all = Novadent.getAppointments()
      .filter(a => a.email.toLowerCase() === activeEmail)
      .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
    const future = all.filter(a => new Date(`${a.date}T${a.time}:00`) >= new Date());
    $('bookingCount').textContent = all.length;
    $('nextVisit').textContent = future.length
      ? new Date(future[0].date + 'T12:00:00').toLocaleDateString('es-ES', { day: '2-digit', month: 'short' })
      : '—';
    $('patientWelcome').textContent = `Hola, ${all[0]?.name.split(' ')[0] || 'paciente'}`;
    renderAppointments(all);
    renderCheckin(future[0] || all[0]);
  }

  function renderAppointments(items) {
    const root = $('patientAppointments');
    root.innerHTML = '';
    if (!items.length) {
      root.innerHTML = '<p class="empty-state">No tienes reservas guardadas.</p>';
      return;
    }
    items.forEach(item => {
      const dateInfo = Novadent.shortDate(item.date);
      const row = document.createElement('div');
      row.className = 'patient-appointment';
      const date = document.createElement('div');
      date.className = 'patient-date';
      date.innerHTML = `<b>${dateInfo.day}</b><small>${dateInfo.month}</small>`;
      const main = document.createElement('div');
      main.className = 'patient-appointment-main';
      const title = document.createElement('b');
      title.textContent = item.service;
      const sub = document.createElement('small');
      sub.textContent = `${dateInfo.week} · ${item.time} · ${item.professional}`;
      main.append(title, sub);
      const actions = document.createElement('div');
      actions.className = 'appointment-actions';
      const change = document.createElement('button');
      change.type = 'button';
      change.textContent = 'Cambiar';
      change.addEventListener('click', () => location.href = `citas.html?modificar=${encodeURIComponent(item.code)}`);
      const reminder = document.createElement('button');
      reminder.type = 'button';
      reminder.className = 'reminder';
      reminder.textContent = 'Recordatorio';
      reminder.addEventListener('click', () => downloadReminder(item));
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'cancel';
      cancel.textContent = 'Cancelar';
      cancel.addEventListener('click', () => cancelAppointment(item));
      actions.append(change, reminder, cancel);
      row.append(date, main, actions);
      root.appendChild(row);
    });
  }

  function downloadReminder(item) {
    const start = new Date(`${item.date}T${item.time}:00`);
    const end = new Date(start.getTime() + 30 * 60000);
    const stamp = date => `${date.getFullYear()}${String(date.getMonth()+1).padStart(2,'0')}${String(date.getDate()).padStart(2,'0')}T${String(date.getHours()).padStart(2,'0')}${String(date.getMinutes()).padStart(2,'0')}00`;
    const alarm = [
      'BEGIN:VALARM', 'TRIGGER:-P1D', 'ACTION:DISPLAY',
      'DESCRIPTION:Recuerda tu cita en Clínica Dental NovaDent', 'END:VALARM'
    ].join('\r\n');
    const content = [
      'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//NovaDent//Agenda de demostracion//ES',
      'BEGIN:VEVENT', `UID:${item.code}@novadent.local`, `DTSTAMP:${stamp(new Date())}`,
      `DTSTART:${stamp(start)}`, `DTEND:${stamp(end)}`, 'SUMMARY:Cita en Clinica Dental NovaDent',
      `DESCRIPTION:${item.service} - Localizador ${item.code}`, alarm, 'END:VEVENT', 'END:VCALENDAR'
    ].join('\r\n');
    const blob = new Blob([content], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `recordatorio-${item.code}.ics`;
    link.click();
    URL.revokeObjectURL(url);
  }

  function cancelAppointment(item) {
    if (!confirm(`¿Quieres cancelar la reserva ${item.code}?`)) return;
    const items = Novadent.getAppointments().filter(a => a.code !== item.code);
    Novadent.saveAppointments(items);
    const waiting = Novadent.getWaitlist().filter(w => w.date === item.date);
    showDashboard();
    if (waiting.length) {
      const note = document.createElement('p');
      note.className = 'form-message';
      note.textContent = 'Se ha liberado un horario y existe una lista de espera para ese día. Esta demostración no envía avisos automáticos.';
      $('patientAppointments').prepend(note);
    }
  }

  function renderCheckin(item) {
    const root = $('checkinContent');
    root.innerHTML = '';
    if (!item) {
      root.innerHTML = '<p class="empty-state">Todavía no hay una cita para generar el QR. Solicita una desde la agenda.</p>';
      return;
    }
    const checkinUrl = new URL('checkin.html', location.href);
    checkinUrl.searchParams.set('ref', item.code);
    const payload = checkinUrl.href;
    const row = document.createElement('div');
    row.className = 'qr-row';
    const img = document.createElement('img');
    img.className = 'qr-image';
    img.alt = 'Código QR de check-in de demostración';
    img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&format=png&data=' + encodeURIComponent(payload);
    img.addEventListener('error', () => {
      const fallback = document.createElement('div');
      fallback.className = 'qr-image';
      fallback.textContent = 'QR no disponible sin conexión a internet';
      img.replaceWith(fallback);
    });
    const info = document.createElement('div');
    info.className = 'qr-info';
    const title = document.createElement('b');
    title.textContent = 'Tu código de llegada';
    const detail = document.createElement('span');
    detail.textContent = `${Novadent.formatDate(item.date)} · ${item.time}`;
    const code = document.createElement('code');
    code.textContent = item.code;
    info.append(title, detail, code);
    row.append(img, info);
    const open = document.createElement('a');
    open.href = payload;
    open.className = 'btn btn-outline';
    open.style.marginTop = '14px';
    open.textContent = 'Abrir check-in de demostración →';
    root.append(row, open);
  }

  $('logoutPatient').addEventListener('click', () => {
    activeEmail = '';
    dashboard.hidden = true;
    login.hidden = false;
    loginForm.reset();
  });
  window.addEventListener('novadent-updated', () => {
    if (activeEmail) showDashboard();
  });

  $('habitsForm').addEventListener('submit', event => {
    event.preventDefault();
    const brushes = Number($('brushes').value);
    const floss = document.querySelector('input[name="floss"]:checked').value;
    const sugar = document.querySelector('input[name="sugar"]:checked').value;
    const checkup = $('checkup').value;
    const sensitivity = document.querySelector('input[name="sensitivity"]:checked').value;
    const tips = [];
    if (brushes < 2) tips.push('Intenta mantener una rutina de cepillado regular, siguiendo las indicaciones de tu profesional.');
    if (floss !== 'yes') tips.push('Pregunta al equipo cómo incorporar la limpieza interdental a tu rutina.');
    if (sugar !== 'low') tips.push('Procura reducir la frecuencia de consumo de alimentos y bebidas azucarados.');
    if (checkup === 'old' || checkup === 'never') tips.push('Valora solicitar una revisión para comprobar el estado de tu salud bucodental.');
    if (sensitivity !== 'no') tips.push('Comenta la sensibilidad o las molestias con un profesional dental.');
    if (!tips.length) tips.push('¡Muy bien! Sigue manteniendo tus hábitos y acude a tus revisiones periódicas.');
    const box = $('habitsResult');
    box.hidden = false;
    box.innerHTML = '<strong>Resumen orientativo de tus respuestas</strong>' + tips.map(t => `<p>• ${t}</p>`).join('') + '<p>Este cuestionario no es un diagnóstico ni sustituye una valoración odontológica.</p>';
    box.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
});
