document.addEventListener('DOMContentLoaded', () => {
  const $ = id => document.getElementById(id);
  const list = $('testimonialList');

  function renderSavedFeedback() {
    if (!list) return;
    let items = [];
    try { items = JSON.parse(localStorage.getItem('novadentFeedback') || '[]'); } catch (e) {}
    list.querySelectorAll('.saved-feedback').forEach(card => card.remove());
    items.slice().reverse().forEach(item => {
      const card = document.createElement('article');
      card.className = 'testimonial-card saved-feedback';
      const label = document.createElement('span');
      label.className = 'demo-label';
      label.textContent = 'VALORACIÓN DE ESTE NAVEGADOR';
      const stars = document.createElement('div');
      stars.className = 'testimonial-stars';
      stars.textContent = '★'.repeat(item.rating) + '☆'.repeat(5 - item.rating);
      const comment = document.createElement('p');
      comment.textContent = item.comment || 'Valoración sin comentario escrito.';
      const name = document.createElement('strong');
      name.textContent = item.name;
      const area = document.createElement('small');
      area.textContent = item.area + ' · Demostración local';
      card.append(label, stars, comment, name, area);
      list.appendChild(card);
    });
  }

  renderSavedFeedback();

  const survey = $('satisfactionForm');
  if (survey) {
    survey.addEventListener('submit', event => {
      event.preventDefault();
      const entry = {
        name: $('satisfactionName').value.trim() || 'Paciente',
        rating: Number($('satisfactionRating').value),
        area: $('satisfactionArea').value,
        comment: $('satisfactionComment').value.trim(),
        created: new Date().toISOString()
      };
      let items = [];
      try { items = JSON.parse(localStorage.getItem('novadentFeedback') || '[]'); } catch (e) {}
      items.push(entry);
      localStorage.setItem('novadentFeedback', JSON.stringify(items));
      $('satisfactionStatus').textContent = 'Gracias por compartir tu valoración. Se ha guardado en este navegador; no se ha enviado ni publicado automáticamente.';
      survey.reset();
      renderSavedFeedback();
    });
  }

  const complaint = $('complaintForm');
  if (complaint) {
    complaint.addEventListener('submit', event => {
      event.preventDefault();
      const name = $('complaintName').value.trim();
      const email = $('complaintEmail').value.trim();
      const type = $('complaintType').value;
      const message = $('complaintText').value.trim();
      const subject = encodeURIComponent(`${type} · Clínica Dental NovaDent`);
      const body = encodeURIComponent(`Nombre: ${name}\nCorreo: ${email}\nTipo: ${type}\n\nMensaje:\n${message}`);
      $('complaintStatus').textContent = 'Se abrirá tu aplicación de correo para que revises y envíes la comunicación.';
      location.href = `mailto:citas@clinicanovadent.es?subject=${subject}&body=${body}`;
    });
  }
});
