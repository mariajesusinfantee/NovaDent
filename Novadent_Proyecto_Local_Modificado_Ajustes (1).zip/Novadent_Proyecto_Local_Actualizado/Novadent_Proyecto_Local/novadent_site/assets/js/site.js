(function(){
  const page = document.body.dataset.page || '';
  const navItems = [
    ['Inicio','index.html','inicio'],
    ['La clínica','clinica.html','clinica'],
    ['Equipo','equipo.html','equipo'],
    ['Tratamientos','tratamientos.html','tratamientos'],
    ['Urgencias','urgencias.html','urgencias'],
    ['Opiniones','opiniones.html','opiniones'],
    ['Contacto','contacto.html','contacto']
  ];
  const logo = `<img class="brand-logo-image" src="assets/img/logo-novadent.png" alt="Clínica Dental Novadent. Una sonrisa nueva, hecha a tu medida">`;
  const header = `
    <div class="site-topbar"><div class="container topbar-inner"><span>Clínica Dental NovaDent · Córdoba</span><div class="topbar-right"><span>Atención cercana</span><span>Entrada accesible</span><label class="font-size-control" for="fontSizeSelect"><span>Tamaño de letra</span><select id="fontSizeSelect" aria-label="Aumentar o reducir el tamaño de letra"><option value="1">Normal</option><option value="1.12">Grande</option><option value="1.25">Muy grande</option><option value="1.4">Extra grande</option></select></label></div></div></div>
    <header class="site-header"><div class="container header-inner">
      <a class="brand" href="index.html" aria-label="NovaDent, inicio">${logo}</a>
      <nav class="main-nav" id="mainNav" aria-label="Navegación principal">${navItems.map(([label,url,key])=>`<a href="${url}" class="${page===key?'active':''}">${label}</a>`).join('')}<a href="pacientes.html" class="${page==='pacientes'?'active':''}">Pacientes</a></nav>
      <div class="header-actions"><a class="header-phone" href="tel:900125456">900 125 456</a><a class="header-book" href="citas.html">Pedir cita ↗</a><button class="menu-toggle" id="menuToggle" type="button" aria-label="Abrir menú" aria-expanded="false">☰</button></div>
    </div></header>`;
  const footer = `
    <footer class="site-footer"><div class="container"><div class="footer-grid">
      <div class="footer-brand"><a class="brand" href="index.html">${logo}</a><p>Un equipo cercano y unas instalaciones pensadas para acompañarte en el cuidado de tu salud bucodental.</p></div>
      <div class="footer-col"><h4>Explora</h4><a href="clinica.html">Nuestra clínica</a><a href="equipo.html">Nuestro equipo</a><a href="tratamientos.html">Tratamientos</a><a href="citas.html">Citas y reservas</a><a href="urgencias.html">Citas de urgencia</a></div>
      <div class="footer-col"><h4>Tu espacio</h4><a href="pacientes.html">Área del paciente</a><a href="pacientes.html#habitos">Hábitos dentales</a><a href="opiniones.html">Opiniones y reclamaciones</a><a href="contacto.html">Contacto y ubicación</a><a href="mailto:citas@clinicanovadent.es">Escríbenos</a></div>
      <div class="footer-col"><h4>Visítanos</h4><p>Avenida de los Olivos, 24<br>Córdoba</p><a href="tel:900125456">900 125 456</a><p class="footer-hours">L–V · 09:00–14:00 · 16:00–19:00</p></div>
    </div><div class="footer-bottom"><span>© <span id="footerYear"></span> Clínica Dental NovaDent</span><span class="footer-local-note">Proyecto local de demostración. Las reservas y el área privada no están conectadas a un servidor clínico.</span></div></div></footer>
    <button class="chat-launcher" id="chatLauncher" type="button" aria-label="Abrir asistente virtual">✧</button>
    <section class="chat-panel" id="chatPanel" aria-label="Asistente virtual NovaDent"><div class="chat-head"><div><strong>Asistente NovaDent</strong><small>Disponible para resolver dudas frecuentes</small></div><button id="chatClose" class="chat-close" type="button" aria-label="Cerrar asistente">×</button></div><div class="chat-messages" id="chatMessages"><div class="chat-bubble bot">¡Hola! Soy el asistente virtual de Novadent. Puedo ayudarte con horarios, ubicación, tratamientos, prótesis dentales, urgencias y reservas. ¿Qué necesitas saber?</div></div><div class="chat-suggestions"><button type="button" data-question="¿Cuál es vuestro horario?">Horarios</button><button type="button" data-question="¿Dónde está la clínica?">Ubicación</button><button type="button" data-question="¿Qué tratamientos ofrecéis?">Tratamientos</button><button type="button" data-question="Explícame los tipos de prótesis dentales">Prótesis</button><button type="button" data-question="Quiero reservar una cita">Reservar cita</button></div><form class="chat-form" id="chatForm"><input id="chatInput" type="text" autocomplete="off" placeholder="Escribe tu pregunta…" aria-label="Escribe tu pregunta"><button type="submit" aria-label="Enviar mensaje">➤</button></form></section>`;
  const headerRoot=document.getElementById('site-header'); if(headerRoot) headerRoot.innerHTML=header;
  const footerRoot=document.getElementById('site-footer'); if(footerRoot) footerRoot.innerHTML=footer;
  const year=document.getElementById('footerYear'); if(year) year.textContent=new Date().getFullYear();

  // Control de tamaño de letra accesible, compartido por todas las páginas.
  const fontSelect=document.getElementById('fontSizeSelect');
  let currentFontScale=1;
  function applyFontScale(scale){
    const previousScale=currentFontScale||1;
    const nextScale=Number(scale)||1;
    const nodes=[document.body,...document.body.querySelectorAll('*')];
    const bases=nodes.map(el=>{
      if(!el.dataset.baseFontSize){
        const measured=parseFloat(getComputedStyle(el).fontSize)||15;
        el.dataset.baseFontSize=String(measured/previousScale);
      }
      return Number(el.dataset.baseFontSize);
    });
    nodes.forEach((el,index)=>{el.style.fontSize=(bases[index]*nextScale)+'px';});
    currentFontScale=nextScale;
    document.documentElement.style.setProperty('--font-accessibility-scale',String(currentFontScale));
  }
  let savedScale='1';
  try{savedScale=localStorage.getItem('novadentFontScale')||'1';}catch(e){}
  if(fontSelect){fontSelect.value=['1','1.12','1.25','1.4'].includes(savedScale)?savedScale:'1';fontSelect.addEventListener('change',()=>{applyFontScale(fontSelect.value);try{localStorage.setItem('novadentFontScale',fontSelect.value);}catch(e){}});}
  applyFontScale(savedScale);
  const fontObserver=new MutationObserver(records=>{if(records.some(record=>record.addedNodes.length))applyFontScale(currentFontScale);});
  fontObserver.observe(document.body,{childList:true,subtree:true});

  const menuToggle=document.getElementById('menuToggle');
  const nav=document.getElementById('mainNav');
  if(menuToggle && nav){menuToggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuToggle.setAttribute('aria-expanded',String(open));menuToggle.textContent=open?'×':'☰';});}
  const launcher=document.getElementById('chatLauncher'), panel=document.getElementById('chatPanel'), close=document.getElementById('chatClose');
  if(launcher && panel){launcher.addEventListener('click',()=>panel.classList.toggle('open'));close.addEventListener('click',()=>panel.classList.remove('open'));}
  const messages=document.getElementById('chatMessages');
  function addBubble(text,who){const bubble=document.createElement('div');bubble.className='chat-bubble '+who;bubble.textContent=text;messages.appendChild(bubble);messages.scrollTop=messages.scrollHeight;}
  function answerQuestion(question){
    const normalize=text=>text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    const q=normalize(question);
    if(q.includes('respirar')||q.includes('tragar')||q.includes('sangrado que no')||q.includes('hinchazon facial')||q.includes('fiebre')||q.includes('dolor intenso')) return 'Si tienes dificultad para respirar o tragar, hinchazón facial importante, fiebre con dolor intenso o un sangrado que no se controla, busca atención sanitaria urgente. Si existe riesgo inmediato, llama al 112. No esperes una respuesta del asistente ni rellenes un formulario.';
    if(q.includes('urgenc')) return 'Atendemos urgencias durante el horario de apertura, sin cita previa. Puedes consultar la página de Citas de urgencia. Si tienes dificultad para respirar o tragar, llama al 112.';
    const mentionsProsthesis=q.includes('protesis')||q.includes('dentadura')||q.includes('sobredentadura')||q.includes('puente dental')||q.includes('corona dental')||q.includes('implante');
    if(mentionsProsthesis){
      if(q.includes('romp')||q.includes('rota')||q.includes('roto')||q.includes('rotura')||q.includes('pegamento')) return 'Si la prótesis se ha roto, no intentes pegarla con pegamentos domésticos ni repararla en casa. Guárdala y contacta con la clínica para que el equipo valore qué hacer.';
      if(q.includes('roza')||q.includes('herida')||q.includes('inflam')||q.includes('molestia')||q.includes('hace dano')||q.includes('duele')) return 'Si la prótesis te roza, te hace daño o tienes heridas o inflamación, no la modifiques ni la limes en casa. Contacta con la clínica para solicitar una revisión. Si aparece hinchazón facial, fiebre o dolor intenso, busca atención sanitaria urgente.';
      if(q.includes('mueve')||q.includes('floja')||q.includes('encaja')) return 'Si la prótesis se mueve, está floja o no encaja, puede haber cambiado su ajuste. No la fuerces y solicita una revisión en la clínica.';
      if(q.includes('mastic')||q.includes('hablar')) return 'Si tienes dificultades para masticar o hablar, puede ser necesario un periodo de adaptación. Si las molestias continúan, consulta con el dentista.';
      if(q.includes('olor')||q.includes('restos')) return 'Si notas mal olor o restos de comida, revisa tu rutina de limpieza y consulta con el equipo si el problema continúa.';
      if(q.includes('dormir')||q.includes('noche')) return '¿Puedes dormir con la prótesis? Depende del tipo de prótesis y de las indicaciones del dentista. Sigue siempre sus recomendaciones.';
      if(q.includes('completa')) return 'La prótesis completa removible sustituye todos los dientes de una arcada (superior, inferior o ambas) y se puede quitar y poner. Límpiala diariamente, mantén limpia la boca y sigue las indicaciones del dentista sobre cuándo retirarla y cómo guardarla.';
      if(q.includes('parcial')&&!q.includes('esquelet')) return 'La prótesis parcial removible sustituye algunos dientes que faltan y se apoya en los dientes naturales que todavía conservas. Limpia la prótesis y los dientes naturales después de las comidas. Retírala y colócala con cuidado, sin forzarla.';
      if(q.includes('esquelet')) return 'La prótesis esquelética es una prótesis parcial removible con una estructura metálica que se sujeta mediante pequeños ganchos. Limpia bien los ganchos y las zonas donde se apoyan sobre los dientes naturales. Evita doblarlos o manipularlos.';
      if(q.includes('acril')) return 'La prótesis acrílica está fabricada principalmente con resina acrílica y puede ser completa o parcial. Límpiala con un cepillo adecuado y productos específicos. Evita el agua caliente y los productos abrasivos.';
      if(q.includes('sobredentadura')) return 'La sobredentadura es una prótesis removible que se sujeta mediante dientes o implantes y proporciona mayor estabilidad. Retírala según las indicaciones del dentista y limpia tanto la prótesis como los elementos de sujeción.';
      if(q.includes('hibrida')) return 'La prótesis híbrida es una prótesis fija que se apoya sobre varios implantes y sustituye una gran cantidad de dientes. Limpia diariamente alrededor de los implantes y debajo de la prótesis utilizando los instrumentos indicados por el profesional.';
      if(q.includes('fija')||q.includes('corona')||q.includes('puente')) return 'Las prótesis fijas, como coronas y puentes, se colocan sobre dientes naturales preparados o sobre implantes y el paciente no las retira habitualmente. Cepilla cuidadosamente y limpia entre los dientes y debajo de los puentes con los instrumentos recomendados por el profesional.';
      if(q.includes('implante')) return 'Las prótesis sobre implantes se sujetan mediante implantes colocados en el hueso y pueden ser fijas o removibles. Mantén limpia la zona de los implantes, elimina los restos de comida y acude a revisiones para comprobar su estado.';
      if(q.includes('provisional')||q.includes('definitiva')) return 'Las prótesis provisionales se utilizan durante un tiempo limitado mientras se prepara el tratamiento definitivo. Las definitivas están diseñadas para un uso prolongado y necesitan mantenimiento y revisiones. Sigue las recomendaciones específicas del dentista para cada una.';
      if(q.includes('pasta')||q.includes('limpiar')||q.includes('limpieza')||q.includes('cuidar')||q.includes('cuidado')||q.includes('higiene')) return 'Limpia la prótesis diariamente con un cepillo adecuado y productos específicos. Algunas pastas de dientes pueden ser abrasivas; evita también la lejía doméstica, el agua caliente y otros productos abrasivos. Evita golpes y caídas. Cepilla suavemente las encías, la lengua y el paladar, y limpia también los dientes naturales que conserves. Mantén la boca hidratada bebiendo agua con frecuencia. No la fuerces, no la modifiques ni la repares en casa. Si tienes dudas, pregunta al dentista cómo colocarla, retirarla y limpiarla.';
      if(q.includes('revisi')||q.includes('mantenim')||q.includes('cada cuanto')||q.includes('dura')) return 'Las revisiones permiten comprobar si la prótesis está bien ajustada, si hay heridas o irritaciones, si los dientes naturales están sanos y si los implantes se mantienen en buen estado. La duración y frecuencia de las revisiones dependen de cada paciente y las establecerá el dentista. No esperes a tener dolor.';
      return 'En NovaDent podemos orientarte sobre prótesis completas removibles, parciales removibles, esqueléticas, acrílicas, fijas (coronas y puentes), sobre implantes, sobredentaduras, híbridas, provisionales y definitivas. Cada tipo necesita cuidados específicos: limpieza diaria, evitar golpes y productos abrasivos, no forzar ni reparar en casa y acudir a las revisiones indicadas por el dentista. ¿Sobre qué tipo de prótesis quieres información?';
    }
    if((q.includes('cuidado')||q.includes('higiene')||q.includes('limpieza'))&&(q.includes('boca')||q.includes('encias')||q.includes('paladar'))) return 'Para cuidar la boca, limpia la prótesis diariamente si la utilizas, cepilla suavemente las encías, la lengua y el paladar, y limpia los dientes naturales que conserves. Mantén hidratada la boca bebiendo agua con frecuencia, evita productos que puedan dañar la prótesis y acude a las revisiones indicadas por el dentista. No uses lejía doméstica, agua caliente ni productos abrasivos.';
    if(q.includes('horario')||q.includes('abierto')||q.includes('abre')||q.includes('cierra')) return 'Nuestro horario es de lunes a viernes de 09:00 a 14:00 y de 16:00 a 19:00. Los fines de semana permanecemos cerrados.';
    if(q.includes('ubic')||q.includes('direc')||q.includes('llegar')||q.includes('donde')) return 'Estamos en Avenida de los Olivos, 24, Córdoba. Las líneas L1, L3 y L7 paran en Olivos-Naranjo, a unos 60 metros. Puedes consultar el mapa en la sección Contacto.';
    if(q.includes('trat')||q.includes('servicio')||q.includes('cirugia')||q.includes('higiene')) return 'En NovaDent trabajamos odontología general, prótesis y rehabilitación, cirugía oral e higiene y prevención. En la página Tratamientos tienes más información.';
    if(q.includes('reserv')||q.includes('cita')||q.includes('agenda')||q.includes('hueco')) return 'Puedes consultar los días y horas disponibles en nuestra agenda de demostración. Pulsa el enlace para ir a Citas y reservas.';
    if(q.includes('telefono')||q.includes('llamar')||q.includes('contact')) return 'Puedes llamarnos al 900 125 456 o escribir a citas@clinicanovadent.es.';
    if(q.includes('personal')||q.includes('equipo')||q.includes('doctora')||q.includes('dentista')) return 'Nuestro equipo está formado por odontólogos, higienistas, una protésica dental y personal de recepción. Puedes conocer sus perfiles en la sección Nuestro equipo.';
    if(q.includes('gracias')) return '¡Gracias a ti! Estoy aquí para ayudarte. ¿Quieres consultar la agenda o conocer la clínica?';
    return 'Puedo orientarte sobre horarios, ubicación, tratamientos, prótesis dentales, cuidados, problemas frecuentes, equipo y reservas. Para cuestiones clínicas personales, habla directamente con el equipo de la clínica.';
  }
  function handleChat(text){if(!text.trim())return;addBubble(text,'user');const reply=answerQuestion(text);addBubble(reply,'bot');const normalized=text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');let target='';let label='';if(reply.includes('agenda de demostración')){target='citas.html';label='Ir a Citas y reservas →';}else if(normalized.includes('urgenc')){target='urgencias.html';label='Abrir formulario de urgencia →';}else if(normalized.includes('protesis')||normalized.includes('dentadura')||normalized.includes('implante')){target='tratamientos.html#protesis';label='Consultar tratamientos de prótesis →';}if(target){const link=document.createElement('a');link.href=target;link.className='chat-bubble bot';link.textContent=label;link.style.display='block';link.style.color='#55788a';messages.appendChild(link);messages.scrollTop=messages.scrollHeight;}}
  const chatForm=document.getElementById('chatForm');
  if(chatForm){chatForm.addEventListener('submit',e=>{e.preventDefault();const input=document.getElementById('chatInput');handleChat(input.value);input.value='';});}
  document.querySelectorAll('[data-question]').forEach(btn=>btn.addEventListener('click',()=>handleChat(btn.dataset.question)));

  // Shared local storage helpers for the demonstration site.
  window.Novadent={
    getAppointments(){try{return JSON.parse(localStorage.getItem('novadentAppointments')||'[]')}catch(e){return[]}},
    saveAppointments(items){localStorage.setItem('novadentAppointments',JSON.stringify(items));window.dispatchEvent(new Event('novadent-updated'));},
    getWaitlist(){try{return JSON.parse(localStorage.getItem('novadentWaitlist')||'[]')}catch(e){return[]}},
    saveWaitlist(items){localStorage.setItem('novadentWaitlist',JSON.stringify(items));},
    formatDate(date){const d=new Date(date+'T12:00:00');return d.toLocaleDateString('es-ES',{weekday:'long',day:'numeric',month:'long',year:'numeric'});},
    shortDate(date){const d=new Date(date+'T12:00:00');return {day:d.toLocaleDateString('es-ES',{day:'2-digit'}),month:d.toLocaleDateString('es-ES',{month:'short'}),week:d.toLocaleDateString('es-ES',{weekday:'short'})};}
  };
})();
