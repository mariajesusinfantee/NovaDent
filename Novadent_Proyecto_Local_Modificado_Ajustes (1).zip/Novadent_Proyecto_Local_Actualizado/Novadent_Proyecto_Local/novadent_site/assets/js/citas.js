document.addEventListener('DOMContentLoaded',()=>{
  const $=id=>document.getElementById(id);
  const dateChoices=$('dateChoices'),timeSlots=$('timeSlots'),message=$('availabilityMessage'),form=$('bookingForm'),result=$('bookingResult');
  if(!dateChoices||!form)return;
  const params=new URLSearchParams(location.search);
  if(params.get('servicio')){$('service').value=params.get('servicio');}
  const modifyCode=params.get('modificar');
  let modifying=modifyCode?Novadent.getAppointments().find(a=>a.code===modifyCode):null;
  let selectedDate='',selectedTime='',dateOffset=0;
  const today=new Date();today.setHours(0,0,0,0);
  function dateKey(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
  function getOpenDates(){let list=[],d=new Date(today);d.setDate(d.getDate()+dateOffset);while(list.length<5){const day=d.getDay();if(day!==0&&day!==6)list.push(new Date(d));d.setDate(d.getDate()+1);if((d-today)/86400000>35)break;}return list;}
  function renderDates(){dateChoices.innerHTML='';getOpenDates().forEach((d,i)=>{const key=dateKey(d),day=d.toLocaleDateString('es-ES',{weekday:'short'}),month=d.toLocaleDateString('es-ES',{month:'short'});const b=document.createElement('button');b.type='button';b.className='date-choice'+(selectedDate===key?' active':'');b.innerHTML=`<small>${day}</small><strong>${d.getDate()}</strong><span>${month}</span>`;b.addEventListener('click',()=>{selectedDate=key;selectedTime='';renderDates();renderTimes();});dateChoices.appendChild(b);});$('prevDates').disabled=dateOffset===0;$('prevDates').style.opacity=dateOffset===0?'.35':'1';}
  function timesFor(date){const out=[];[[9,14],[16,19]].forEach(([start,end])=>{for(let minutes=start*60;minutes<end*60;minutes+=30){const h=Math.floor(minutes/60),m=minutes%60;out.push(`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}`);}});return out;}
  function renderTimes(){timeSlots.innerHTML='';message.textContent='';if(!selectedDate){timeSlots.innerHTML='<p class="empty-state">Selecciona primero un día para ver las horas.</p>';return;}const bookings=Novadent.getAppointments();const times=timesFor(selectedDate);let free=0;times.forEach(time=>{const busy=bookings.some(a=>a.date===selectedDate&&a.time===time&&(!modifying||a.code!==modifying.code));const b=document.createElement('button');b.type='button';b.className='time-slot'+(busy?' occupied':'')+(selectedTime===time?' active':'');b.textContent=time;b.disabled=busy;b.title=busy?'Hora ocupada':'Hora disponible';if(!busy)free++;b.addEventListener('click',()=>{selectedTime=time;document.querySelectorAll('.time-slot').forEach(x=>x.classList.remove('active'));b.classList.add('active');message.textContent=`Has seleccionado ${time} · ${Novadent.formatDate(selectedDate)}.`;});timeSlots.appendChild(b);});const legend=document.createElement('div');legend.className='slot-legend';legend.innerHTML='<span><i></i> Disponible</span><span class="busy"><i></i> Ocupada</span>';timeSlots.appendChild(legend);if(free===0)message.textContent='No quedan horas libres para este día. Puedes apuntarte a la lista de espera.';}
  $('prevDates').addEventListener('click',()=>{dateOffset=Math.max(0,dateOffset-7);renderDates();});$('nextDates').addEventListener('click',()=>{dateOffset+=7;selectedDate='';selectedTime='';renderDates();renderTimes();});
  if(modifying){$('patientName').value=modifying.name;$('patientPhone').value=modifying.phone;$('patientEmail').value=modifying.email;const banner=document.createElement('div');banner.className='form-message';banner.style.marginBottom='15px';banner.textContent=`Estás cambiando la reserva ${modifying.code}. Selecciona una nueva fecha y hora.`;form.prepend(banner);}
  const first=getOpenDates()[0];selectedDate=dateKey(first);renderDates();renderTimes();
  function downloadReceiptPNG(item){
    const canvas=document.createElement('canvas');canvas.width=1500;canvas.height=1050;
    const ctx=canvas.getContext('2d');ctx.fillStyle='#fffdfa';ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.strokeStyle='#d6a0b5';ctx.lineWidth=5;ctx.strokeRect(34,34,canvas.width-68,canvas.height-68);
    ctx.strokeStyle='#a9c6dd';ctx.lineWidth=2;ctx.strokeRect(50,50,canvas.width-100,canvas.height-100);
    ctx.fillStyle='#667d8d';ctx.font='600 22px Arial';ctx.fillText('CLÍNICA DENTAL · CÓRDOBA',95,120);
    ctx.fillStyle='#284455';ctx.font='700 48px Arial';ctx.fillText('JUSTIFICANTE DE ASISTENCIA',95,205);
    ctx.fillStyle='#bd829c';ctx.fillRect(95,232,575,5);
    const logo=new Image();logo.onload=()=>{
      const maxW=490,maxH=230,ratio=Math.min(maxW/logo.width,maxH/logo.height);
      const w=logo.width*ratio,h=logo.height*ratio;ctx.drawImage(logo,canvas.width-95-w,72,w,h);
      drawReceiptText();
    };logo.onerror=drawReceiptText;logo.src='assets/img/logo-novadent.png';
    function drawReceiptText(){
      ctx.fillStyle='#637785';ctx.font='400 24px Arial';ctx.fillText('Se hace constar que la persona indicada tiene una cita programada en',95,300,740);ctx.fillText('Clínica Dental NovaDent en la fecha y hora que se detallan a continuación.',95,338,740);
      ctx.fillStyle='#f6eef1';ctx.fillRect(95,395,1310,330);ctx.strokeStyle='#e5d2dc';ctx.lineWidth=2;ctx.strokeRect(95,395,1310,330);
      const fields=[['PACIENTE',item.name],['FECHA DE LA CITA',Novadent.formatDate(item.date)],['HORA',item.time],['MOTIVO DE LA VISITA',item.service],['PROFESIONAL',item.professional],['LOCALIZADOR',item.code]];
      let y=455;fields.forEach((field,index)=>{ctx.fillStyle='#8e8290';ctx.font='700 17px Arial';ctx.fillText(field[0],130,y);ctx.fillStyle='#2f4857';ctx.font='600 25px Arial';ctx.fillText(String(field[1]||'No especificado'),430,y,900);y+=index===1?70:58;});
      ctx.fillStyle='#526b78';ctx.font='400 19px Arial';ctx.fillText('Dirección: Avenida de los Olivos, 24 · Córdoba',95,795);ctx.fillText('Teléfono: 900 125 456 · citas@clinicanovadent.es',95,830);
      ctx.fillStyle='#7d8890';ctx.font='400 17px Arial';ctx.fillText('Emitido el '+new Date().toLocaleDateString('es-ES'),95,900);
      ctx.fillStyle='#334d5c';ctx.font='700 20px Arial';ctx.fillText('Recepción · Clínica Dental NovaDent',95,955);
      ctx.fillStyle='#9a7485';ctx.font='400 15px Arial';ctx.fillText('Este documento acredita la cita programada. La asistencia efectiva deberá confirmarse en recepción el día de la visita.',95,990);
      canvas.toBlob(blob=>{if(!blob){const fallback=document.createElement('a');fallback.href=canvas.toDataURL('image/png');fallback.download='justificante-'+item.code+'.png';fallback.click();return;}const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='justificante-'+item.code+'.png';link.click();setTimeout(()=>URL.revokeObjectURL(url),1500);},'image/png');
    }
  }
  form.addEventListener('submit',e=>{e.preventDefault();if(!selectedDate||!selectedTime){message.textContent='Selecciona un día y una hora antes de continuar.';return;}let list=Novadent.getAppointments();if(list.some(a=>a.date===selectedDate&&a.time===selectedTime&&(!modifying||a.code!==modifying.code))){message.textContent='Ese horario acaba de ocuparse. Selecciona otro, por favor.';renderTimes();return;}if(modifying)list=list.filter(a=>a.code!==modifying.code);const code='ND-'+Math.random().toString(36).slice(2,8).toUpperCase();const item={code,date:selectedDate,time:selectedTime,service:$('service').value,professional:$('professional').value||'Cualquiera disponible',name:$('patientName').value.trim(),phone:$('patientPhone').value.trim(),email:$('patientEmail').value.trim(),created:new Date().toISOString(),status:'Pendiente · demostración'};list.push(item);Novadent.saveAppointments(list);modifying=null;result.hidden=false;result.innerHTML=`<h3>✓ Solicitud guardada en este navegador</h3><p>Localizador: <strong>${item.code}</strong></p><p>${Novadent.formatDate(item.date)} a las ${item.time}</p><p>${item.service}</p><p>Esta es una reserva de demostración, no una cita confirmada por la clínica. El justificante acredita la cita programada, no la asistencia efectiva.</p><button id="downloadAppointmentReceipt" class="btn btn-primary receipt-download" type="button">Descargar justificante en PNG ↓</button><a href="pacientes.html">Abrir área del paciente →</a>`;document.getElementById('downloadAppointmentReceipt').addEventListener('click',()=>downloadReceiptPNG(item));result.scrollIntoView({behavior:'smooth',block:'center'});form.reset();$('service').value=params.get('servicio')||'Primera visita / Revisión';selectedTime='';renderTimes();});
  $('waitlistForm').addEventListener('submit',e=>{e.preventDefault();const items=Novadent.getWaitlist();items.push({name:$('waitName').value.trim(),email:$('waitEmail').value.trim(),date:selectedDate,period:$('waitPeriod').value,created:new Date().toISOString()});Novadent.saveWaitlist(items);$('waitlistMessage').textContent='Te hemos añadido a la lista de espera local de esta demostración. No se enviará un aviso automático.';e.target.reset();});
  window.addEventListener('storage',e=>{if(e.key==='novadentAppointments')renderTimes();});window.addEventListener('novadent-updated',renderTimes);
});
