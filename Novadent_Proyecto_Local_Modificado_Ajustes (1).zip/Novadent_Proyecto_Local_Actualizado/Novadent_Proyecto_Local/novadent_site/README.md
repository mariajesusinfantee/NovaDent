# Clínica Dental Novadent · Proyecto web local

Proyecto multipágina para abrir y editar desde Visual Studio Code. Está construido con HTML, CSS y JavaScript, sin WordPress ni necesidad de dominio.

## Cómo abrir la web

1. Descarga y descomprime `Novadent_Proyecto_Local.zip`.
2. Abre Visual Studio Code.
3. En el menú, selecciona **Archivo → Abrir carpeta**.
4. Selecciona la carpeta `novadent_site` que acabas de descomprimir.
5. En Visual Studio Code, abre el archivo `index.html`.
6. Para verla correctamente, instala la extensión **Live Server**. Después, haz clic derecho sobre `index.html` y selecciona **Open with Live Server**.

También puedes abrir `index.html` haciendo doble clic, aunque Live Server es la opción recomendada para probar todas las páginas.

## Páginas incluidas

- `index.html`: página de inicio y presentación de Novadent.
- `clinica.html`: instalaciones, zonas, accesibilidad y plano de planta.
- `equipo.html`: perfiles del equipo profesional.
- `tratamientos.html`: áreas de atención odontológica.
- `citas.html`: agenda visual, elección de fecha y hora, reservas y lista de espera.
- `pacientes.html`: área del paciente, próximas citas, cambios, cancelaciones, recordatorio descargable, QR y cuestionario de hábitos.
- `contacto.html`: datos de contacto, horario, mapa esquemático e indicaciones para llegar.
- `checkin.html`: página de confirmación de llegada mediante el localizador del QR.

## Funciones de demostración

- El menú enlaza todas las páginas y se adapta a móviles.
- El asistente virtual responde preguntas frecuentes sobre horarios, ubicación, tratamientos, equipo y reservas.
- La agenda muestra las horas disponibles y bloquea las que ya se hayan reservado en este navegador.
- Las reservas se guardan en `localStorage` del navegador. El área privada permite consultarlas, cambiarlas y cancelarlas usando el correo y el localizador de la reserva.
- La lista de espera se guarda localmente. No envía mensajes automáticos cuando aparece un hueco.
- En el área del paciente se puede descargar un archivo de calendario `.ics` con un aviso de un día antes, para importarlo en una aplicación compatible.
- El QR se genera con un servicio externo de códigos QR y abre la página local de check-in. Para generar la imagen QR es necesaria conexión a Internet.
- El formulario de contacto prepara un correo y abre el programa de correo instalado en el equipo.
- El cuestionario de hábitos muestra consejos generales; las respuestas no se envían ni se guardan.

## Importante: límites de esta versión local

Este proyecto es una demostración para prácticas y pruebas en un equipo. No es un sistema clínico listo para atender pacientes reales.

- Las reservas solo se comparten dentro del mismo navegador y dispositivo. No existe una agenda central en tiempo real entre distintos usuarios.
- La confirmación aparece en pantalla, pero no se envían correos ni SMS. Los recordatorios se descargan como archivo de calendario; no se programan desde un servidor.
- La lista de espera no envía avisos automáticos.
- El área privada usa un correo y un localizador de demostración, no una autenticación segura. No introduzcas datos reales ni información médica.
- El check-in QR queda registrado en el almacenamiento local de este navegador. No está conectado a un lector físico ni a recepción.
- El asistente virtual usa respuestas predefinidas; no es un chatbot conectado a inteligencia artificial.
- Para convertir estas funciones en servicios reales se necesitarían un servidor, base de datos, inicio de sesión seguro, protección de datos y servicios de correo/SMS.

## Datos utilizados

Los datos de ubicación, horarios, superficie, instalaciones, accesibilidad, plano y personal se han tomado del documento de trabajo facilitado para Clínica Dental Novadent. Se han omitido los datos personales del caso clínico que aparece al final del PDF.

## Archivos principales

```text
novadent_site/
├── index.html
├── clinica.html
├── equipo.html
├── tratamientos.html
├── citas.html
├── pacientes.html
├── contacto.html
├── checkin.html
└── assets/
    ├── css/style.css
    ├── js/site.js
    ├── js/citas.js
    ├── js/pacientes.js
    ├── js/contacto.js
    ├── js/checkin.js
    ├── img/
    └── photos/
```


## Actualización de funciones

- El encabezado y el pie utilizan `assets/img/logo-novadent.png`, el logotipo PNG completo facilitado para la clínica.
- El selector de accesibilidad permite ampliar el tamaño de letra en todas las páginas y conserva la preferencia en este navegador.
- La agenda oculta los huecos 09:00, 14:00, 14:30 y 16:00.
- Al guardar una cita de demostración aparece la opción de descargar un justificante en PNG. El documento acredita la cita programada, no la asistencia efectiva; esta debe validarse en recepción.
- `urgencias.html` incorpora un formulario abreviado y llamada telefónica directa. El formulario prepara un correo en la aplicación del usuario; no es un servicio de emergencias.
- `opiniones.html` incorpora encuesta de satisfacción local, valoraciones ficticias claramente identificadas como ejemplos y formulario de reclamaciones que prepara un correo.
- El asistente incluye información general sobre tipos y cuidados de prótesis, problemas frecuentes y cuándo solicitar atención profesional.

Las funciones locales siguen siendo una demostración: no hay servidor, envío automático de correos/SMS ni publicación centralizada de valoraciones.
